﻿namespace PROG6221POE
{
    public class QuizQuestion
    {
        public string Question { get; set; } = "";

        public string CorrectAnswer { get; set; } = "";
    }
}
