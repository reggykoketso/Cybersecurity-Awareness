﻿using System.Collections.Generic;

namespace PROG6221POE
{
    public class QuizManager
    {
        public List<QuizQuestion> Questions =
            new List<QuizQuestion>()
        {
            new QuizQuestion()
            {
                Question = "What is phishing?",
                CorrectAnswer = "A scam"
            },

            new QuizQuestion()
            {
                Question = "Should you share your password?",
                CorrectAnswer = "No"
            },

            new QuizQuestion()
            {
                Question = "What does 2FA stand for?",
                CorrectAnswer = "Two Factor Authentication"
            },

            new QuizQuestion()
            {
                Question = "Is public WiFi always safe?",
                CorrectAnswer = "No"
            },

            new QuizQuestion()
            {
                Question = "Should you click suspicious links?",
                CorrectAnswer = "No"
            }
        };
    }
}