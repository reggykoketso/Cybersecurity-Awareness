﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PROG6221POE
{
    public static class ActivityLogger
    {
        private static List<string> logs = new();

        public static void Log(string action)
        {
            logs.Add($"{DateTime.Now:HH:mm:ss} - {action}");
        }

        public static string GetRecentLogs()
        {
            return string.Join(
                Environment.NewLine,
                logs.TakeLast(10));
        }
    }
}