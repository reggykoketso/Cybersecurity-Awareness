using System.IO;
using System.Media;
using System.Windows.Forms;

namespace PROG6221POE
{
    public static class AudioPlayer
    {
        public static void PlayGreeting()
        {
            PlayGreeting(Path.Combine(Application.StartupPath, "greeting.wav"));
        }

        public static void PlayGreeting(string filePath)
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    return;
                }

                using SoundPlayer player = new SoundPlayer(filePath);
                player.Load();
                player.Play();
            }
            catch
            {
                // Audio is optional, so the chatbot should keep running if sound fails.
            }
        }
    }
}
