﻿namespace PROG6221POE
{
    public class TaskItem
    {
        public string Title { get; set; } = "";

        public string Description { get; set; } = "";

        public string Reminder { get; set; } = "";

        public bool Completed { get; set; }
    }
}
