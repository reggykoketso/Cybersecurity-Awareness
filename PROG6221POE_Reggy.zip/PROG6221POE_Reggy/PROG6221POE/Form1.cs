using System;
using System.Drawing;
using System.Windows.Forms;

namespace PROG6221POE
{
    public partial class Form1 : Form
    {
        private readonly Color accent = Color.FromArgb(214, 72, 39);
        private readonly Color accentDark = Color.FromArgb(164, 47, 28);
        private readonly Color page = Color.FromArgb(255, 248, 244);
        private readonly Color panel = Color.White;
        private readonly Color text = Color.FromArgb(55, 43, 37);
        private readonly Color muted = Color.FromArgb(116, 100, 91);

        private ChatbotEngine? bot;

        private Label? lblTitle;
        private Label? lblSubtitle;
        private Label? lblName;
        private Label? lblClock;
        private TextBox? txtName;
        private TextBox? txtInput;
        private Button? btnStart;
        private Button? btnSend;
        private Button? btnTasks;
        private Button? btnQuiz;
        private Button? btnLog;
        private RichTextBox? rtbChat;
        private System.Windows.Forms.Timer? clockTimer;

        public Form1()
        {
            InitializeComponent();
            BuildInterface();
        }

        private void BuildInterface()
        {
            Text = "CyberSecure Bot";
            Size = new Size(980, 730);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = page;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            lblTitle = new Label();
            lblTitle.Text = "CyberSecure Bot";
            lblTitle.ForeColor = accent;
            lblTitle.Font = new Font("Segoe UI Semibold", 28, FontStyle.Bold);
            lblTitle.Location = new Point(40, 22);
            lblTitle.AutoSize = true;
            Controls.Add(lblTitle);

            lblSubtitle = new Label();
            lblSubtitle.Text = "Online safety assistant";
            lblSubtitle.ForeColor = muted;
            lblSubtitle.Font = new Font("Segoe UI", 11);
            lblSubtitle.Location = new Point(44, 76);
            lblSubtitle.AutoSize = true;
            Controls.Add(lblSubtitle);

            lblClock = new Label();
            lblClock.ForeColor = accentDark;
            lblClock.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
            lblClock.Location = new Point(750, 34);
            lblClock.Size = new Size(180, 28);
            lblClock.TextAlign = ContentAlignment.MiddleRight;
            Controls.Add(lblClock);

            clockTimer = new System.Windows.Forms.Timer();
            clockTimer.Interval = 1000;
            clockTimer.Tick += (s, e) => UpdateClock();
            clockTimer.Start();
            UpdateClock();

            lblName = new Label();
            lblName.Text = "USER";
            lblName.ForeColor = text;
            lblName.Font = new Font("Segoe UI Semibold", 10, FontStyle.Bold);
            lblName.Location = new Point(44, 120);
            lblName.Size = new Size(60, 32);
            lblName.TextAlign = ContentAlignment.MiddleLeft;
            Controls.Add(lblName);

            txtName = new TextBox();
            txtName.Location = new Point(105, 118);
            txtName.Size = new Size(300, 32);
            txtName.Font = new Font("Segoe UI", 11);
            txtName.BackColor = panel;
            txtName.ForeColor = Color.Gray;
            txtName.BorderStyle = BorderStyle.FixedSingle;
            txtName.Text = "Enter your name...";
            txtName.Enter += TxtName_Enter;
            txtName.Leave += TxtName_Leave;
            Controls.Add(txtName);

            btnStart = CreateButton("CONNECT", new Point(420, 116), new Size(150, 36));
            btnStart.Click += BtnStart_Click;
            Controls.Add(btnStart);

            rtbChat = new RichTextBox();
            rtbChat.Location = new Point(40, 178);
            rtbChat.Size = new Size(890, 375);
            rtbChat.ReadOnly = true;
            rtbChat.BackColor = panel;
            rtbChat.ForeColor = text;
            rtbChat.BorderStyle = BorderStyle.FixedSingle;
            rtbChat.Font = new Font("Consolas", 10);
            Controls.Add(rtbChat);

            btnTasks = CreateButton("TASKS", new Point(40, 575), new Size(130, 34));
            btnTasks.Enabled = false;
            btnTasks.Click += (s, e) => SubmitMessage("show tasks");
            Controls.Add(btnTasks);

            btnQuiz = CreateButton("QUIZ", new Point(180, 575), new Size(130, 34));
            btnQuiz.Enabled = false;
            btnQuiz.Click += (s, e) => SubmitMessage("start quiz");
            Controls.Add(btnQuiz);

            btnLog = CreateButton("LOG", new Point(320, 575), new Size(130, 34));
            btnLog.Enabled = false;
            btnLog.Click += (s, e) => SubmitMessage("show activity log");
            Controls.Add(btnLog);

            txtInput = new TextBox();
            txtInput.Location = new Point(40, 625);
            txtInput.Size = new Size(730, 34);
            txtInput.Font = new Font("Segoe UI", 11);
            txtInput.BackColor = panel;
            txtInput.ForeColor = text;
            txtInput.BorderStyle = BorderStyle.FixedSingle;
            txtInput.Enabled = false;
            txtInput.KeyDown += TxtInput_KeyDown;
            Controls.Add(txtInput);

            btnSend = CreateButton("SEND", new Point(790, 623), new Size(140, 38));
            btnSend.Enabled = false;
            btnSend.Click += BtnSend_Click;
            Controls.Add(btnSend);
        }

        private Button CreateButton(string label, Point location, Size size)
        {
            Button button = new Button();
            button.Text = label;
            button.Location = location;
            button.Size = size;
            button.BackColor = accent;
            button.ForeColor = Color.White;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.Font = new Font("Segoe UI Semibold", 10, FontStyle.Bold);
            button.Cursor = Cursors.Hand;
            button.UseVisualStyleBackColor = false;
            button.MouseEnter += (s, e) => button.BackColor = accentDark;
            button.MouseLeave += (s, e) => button.BackColor = accent;
            return button;
        }

        private void UpdateClock()
        {
            lblClock!.Text = DateTime.Now.ToString("HH:mm:ss");
        }

        private void TxtName_Enter(object? sender, EventArgs e)
        {
            if (txtName!.Text == "Enter your name...")
            {
                txtName.Text = "";
                txtName.ForeColor = text;
            }
        }

        private void TxtName_Leave(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName!.Text))
            {
                txtName.Text = "Enter your name...";
                txtName.ForeColor = Color.Gray;
            }
        }

        private void BtnStart_Click(object? sender, EventArgs e)
        {
            string name = txtName!.Text.Trim();

            if (string.IsNullOrWhiteSpace(name) || name == "Enter your name...")
            {
                name = "Friend";
            }

            bot = new ChatbotEngine(name);
            rtbChat!.Clear();

            AddBotMessage(bot.GetAsciiArt());
            AddBotMessage("Connected. Welcome, " + name + ".");
            AddBotMessage("Ask about phishing, passwords, scams, privacy, safe browsing, public Wi-Fi, 2FA, tasks, activity logs, or the quiz.");
            AddBotMessage("Try: add task update my password tomorrow, show tasks, start quiz, or show activity log.");

            AudioPlayer.PlayGreeting();

            txtInput!.Enabled = true;
            btnSend!.Enabled = true;
            btnTasks!.Enabled = true;
            btnQuiz!.Enabled = true;
            btnLog!.Enabled = true;
            txtInput.Focus();
        }

        private void BtnSend_Click(object? sender, EventArgs e)
        {
            ProcessUserInput();
        }

        private void TxtInput_KeyDown(object? sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                ProcessUserInput();
                e.SuppressKeyPress = true;
            }
        }

        private void ProcessUserInput()
        {
            SubmitMessage(txtInput!.Text.Trim());
            txtInput.Clear();
            txtInput.Focus();
        }

        private void SubmitMessage(string userInput)
        {
            if (bot == null)
            {
                MessageBox.Show("Connect to the assistant first.");
                return;
            }

            if (string.IsNullOrWhiteSpace(userInput))
            {
                AddBotMessage("Please enter a message.");
                return;
            }

            AddUserMessage(userInput);
            AddBotMessage(bot.GetResponse(userInput));
        }

        private void AddUserMessage(string message)
        {
            rtbChat!.SelectionColor = accentDark;
            rtbChat.AppendText("[" + DateTime.Now.ToString("HH:mm") + "] YOU > " + message + Environment.NewLine + Environment.NewLine);
            rtbChat.SelectionColor = text;
        }

        private void AddBotMessage(string message)
        {
            rtbChat!.SelectionColor = text;
            rtbChat.AppendText("[" + DateTime.Now.ToString("HH:mm") + "] CYBERSECURE > " + message + Environment.NewLine + Environment.NewLine);
            rtbChat.SelectionColor = text;
            rtbChat.ScrollToCaret();
        }
    }
}
